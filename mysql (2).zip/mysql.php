<?php
// Konfigurasi database AWS RDS
// Masukkan Endpoint AWS RDS Anda ke dalam $db_host (contoh: database-1.xxxx.us-east-1.rds.amazonaws.com)
$db_host = '';
// Masukkan Nama Database (Initial database name yang Anda tentukan saat membuat RDS)
$db_name = ''; 
$db_user = 'admin';
$db_pass = 'unsadaunggul';

// 1. Membuat koneksi menggunakan MySQLi dengan try-catch
try {
    if (empty($db_host)) {
        die("PERINGATAN: Variabel \$db_host masih kosong! Silakan masukkan Endpoint database Anda di baris 4.\n");
    }

    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    $line_break = (php_sapi_name() === 'cli') ? "\n" : "<br>";
    echo "Konek ke database AWS" . $line_break;

    // 2. Menjalankan kueri
    $sql = "SELECT version()";
    $result = $conn->query($sql);

    if ($result) {
        // 3. Mengambil hasil
        $row = $result->fetch_row();
        $db_version = $row[0];

        // 4. Menampilkan versi database
        echo "Versi Database: " . $db_version . $line_break;

        $result->free();
    } else {
        echo "Error query: " . $conn->error . $line_break;
    }

    // 5. Menutup koneksi
    $conn->close();

} catch (mysqli_sql_exception $e) {
    $line_break = (php_sapi_name() === 'cli') ? "\n" : "<br>";
    echo "Koneksi Gagal: " . $e->getMessage() . $line_break;
}
?>
